var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// functions/index.js
var { PrismaClient, Prisma } = require("@prisma/client");
var client = new PrismaClient();
exports.handler = async function(event, context, callback) {
  await client.user.deleteMany({});
  const id = "12345";
  const createUser = await client.user.create({
    data: {
      id,
      email: "alice@prisma.io",
      name: "Alice"
    }
  });
  const updateUser = await client.user.update({
    where: {
      id
    },
    data: {
      email: "bob@prisma.io",
      name: "Bob"
    }
  });
  const users = await client.user.findUnique({
    where: {
      id
    }
  });
  const deleteManyUsers = await client.user.deleteMany();
  const fs = require("fs");
  const path = require("path");
  const files = fs.readdirSync(path.dirname(require.resolve(".prisma/client")));
  return {
    statusCode: 200,
    body: JSON.stringify({
      version: Prisma.prismaVersion.client,
      createUser,
      updateUser,
      users,
      deleteManyUsers,
      files
    }),
    headers: {
      "Access-Control-Allow-Origin": "*"
    }
  };
};
